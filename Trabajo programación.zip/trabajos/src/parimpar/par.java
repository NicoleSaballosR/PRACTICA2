package parimpar;

import java.util.Scanner;
public class par {

	public static void main (String[] args) {
		// calcular si es par o impar
		
		try (Scanner teclado = new Scanner(System.in)) {
			int numero ;
			
			System.out.println("ingrese el numero");
			numero= teclado.nextInt();
			
			if (numero%2 == 0) { 
				System.out.print("El numero es par"); 
				}
			
			else { 
				System.out.print("El numero es impar"); 
			}
		}
		
	}

}